/**
 * Hero controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::hero.hero' as any);
